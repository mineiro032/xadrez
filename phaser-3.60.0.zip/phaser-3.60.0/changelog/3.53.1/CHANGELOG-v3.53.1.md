# Phaser 3 Change Log

## Version 3.53.1 - Anastasia - 8th March 2021

* Fixed an issue where Container children were not removed from the display list properly.
