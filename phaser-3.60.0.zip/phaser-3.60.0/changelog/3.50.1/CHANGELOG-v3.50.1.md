# Phaser 3 Change Log

## Version 3.50.1 - Subaru - 21st December 2020

* The new Web Audio Panning feature breaks WebAudio on Safari (OSX and iOS). The stereo panner node is now only created if supported. Fix #5460 (thanks @d4rkforce)
