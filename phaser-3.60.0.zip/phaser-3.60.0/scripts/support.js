/* eslint-disable no-console */

const red = '\u001b[91m';
const green = '\u001b[92m';
const yellow = '\u001b[93m\u001b[1m';
const reset = '\u001b[0m';

console.log(`${red}❤ ${green}Please help support Phaser development ${red}❤`);
console.log(`${yellow}https://www.patreon.com/photonstorm/\n${reset}`);
